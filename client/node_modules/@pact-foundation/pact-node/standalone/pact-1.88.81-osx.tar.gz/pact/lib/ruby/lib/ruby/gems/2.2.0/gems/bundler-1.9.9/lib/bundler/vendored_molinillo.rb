module Bundler; end
require 'bundler/vendor/molinillo/lib/molinillo'
